/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author thorashim
 */
// Client.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class Client extends JFrame implements ActionListener {
    JTextField textField;
    JPanel chatPanel;
    JScrollPane scrollPane;
    JButton sendButton, fileButton;
    JLabel typingLabel;
    Timer typingTimer;
    DataInputStream dis;
    DataOutputStream dos;
    Socket socket;
    String username;
    Image userAvatar;
    File avatarFile;
    static HashMap<String, String> emojiMap;

    public Client() {
        username = JOptionPane.showInputDialog(this, "Enter your username:");
        if (username == null || username.trim().isEmpty()) username = "Anonymous";

        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose your profile picture");
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            try {
                avatarFile = chooser.getSelectedFile();
                userAvatar = ImageIO.read(avatarFile).getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            } catch (IOException e) {
                userAvatar = new ImageIcon("avatar.png").getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            }
        } else {
            userAvatar = new ImageIcon("avatar.png").getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        }

        setTitle("WhatsChat - " + username);
        setSize(450, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.WHITE);
        header.setPreferredSize(new Dimension(450, 60));

        ImageIcon circleIcon = new ImageIcon(makeRoundedImage(userAvatar));
        JLabel avatar = new JLabel(circleIcon);
        avatar.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

        JLabel nameLabel = new JLabel(username);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        nameLabel.setForeground(Color.BLACK);

        typingLabel = new JLabel("Active now");
        typingLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        typingLabel.setForeground(Color.GRAY);

        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setBackground(Color.WHITE);
        leftPanel.add(nameLabel);
        leftPanel.add(typingLabel);

        JPanel topLeft = new JPanel(new FlowLayout(FlowLayout.LEFT));
        topLeft.setBackground(Color.WHITE);
        topLeft.add(avatar);
        topLeft.add(leftPanel);
        header.add(topLeft, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        chatPanel.setBackground(new Color(240, 240, 240));
        scrollPane = new JScrollPane(chatPanel);
        add(scrollPane, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(Color.WHITE);
        textField = new JTextField();
        sendButton = new JButton("Send");
        fileButton = new JButton("\uD83D\uDCC1");

        JPanel rightBottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightBottom.add(fileButton);
        rightBottom.add(sendButton);
        bottom.add(textField, BorderLayout.CENTER);
        bottom.add(rightBottom, BorderLayout.EAST);
        add(bottom, BorderLayout.SOUTH);

        sendButton.addActionListener(this);
        textField.addActionListener(this);
        fileButton.addActionListener(e -> sendFile());

        textField.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                try {
                    dos.writeUTF("TYPING");
                    dos.writeUTF(username);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        emojiMap = new HashMap<>();
        emojiMap.put(":)", "😊");
        emojiMap.put(":(", "☹");
        emojiMap.put("<3", "❤");
        emojiMap.put(":D", "😄");

        try {
            socket = new Socket("localhost", 50005);
            dis = new DataInputStream(socket.getInputStream());
            dos = new DataOutputStream(socket.getOutputStream());
            dos.writeUTF(username);

            // ✅ Send profile picture
            if (avatarFile != null && avatarFile.exists()) {
                dos.writeUTF(avatarFile.getName());
                dos.writeLong(avatarFile.length());
                FileInputStream fis = new FileInputStream(avatarFile);
                byte[] buffer = new byte[4096];
                int read;
                while ((read = fis.read(buffer)) > 0) {
                    dos.write(buffer, 0, read);
                }
                fis.close();
            } else {
                dos.writeUTF("default.png");
                dos.writeLong(0);
            }

            new Thread(() -> {
                try {
                    while (true) {
                        String type = dis.readUTF();
                        if (type.equals("MSG")) {
                            String msg = dis.readUTF();
                            addMessage(msg, false);
                        } else if (type.equals("TYPING")) {
                            String who = dis.readUTF();
                            showTyping(who);
                        } else if (type.equals("FILE")) {
                            String sender = dis.readUTF();
                            String filename = dis.readUTF();
                            long size = dis.readLong();
                            File outFile = new File("Received_" + filename);
                            FileOutputStream fos = new FileOutputStream(outFile);
                            byte[] buffer = new byte[4096];
                            long remaining = size;
                            while (remaining > 0) {
                                int read = dis.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                                if (read == -1) break;
                                fos.write(buffer, 0, read);
                                remaining -= read;
                            }
                            fos.close();

                            String lower = filename.toLowerCase();
                            if (lower.endsWith(".jpg") || lower.endsWith(".png") ||
                                lower.endsWith(".jpeg") || lower.endsWith(".gif")) {
                                ImageIcon imgIcon = new ImageIcon(
                                        ImageIO.read(outFile).getScaledInstance(150, 150, Image.SCALE_SMOOTH));
                                JLabel imgLabel = new JLabel(imgIcon);
                                imgLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                                imgLabel.addMouseListener(new MouseAdapter() {
                                    public void mouseClicked(MouseEvent e) {
                                        try {
                                            Desktop.getDesktop().open(outFile);
                                        } catch (IOException ex) {
                                            ex.printStackTrace();
                                        }
                                    }
                                });
                                JPanel panel = new JPanel(new BorderLayout());
                                panel.add(new JLabel(
                                        sender + " sent image (" + (size / 1024) + " KB):"), BorderLayout.NORTH);
                                panel.add(imgLabel, BorderLayout.CENTER);
                                chatPanel.add(panel);
                            } else {
                                addMessage(sender + " sent file: " + outFile.getName() +
                                        " (" + (size / 1024) + " KB)", false);
                            }
                            chatPanel.revalidate();
                            SwingUtilities.invokeLater(() ->
                                scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum()));
                        }
                    }
                } catch (IOException ex) {
                    addMessage("Disconnected from server.", false);
                }
            }).start();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Server not available");
            System.exit(0);
        }

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String msg = textField.getText().trim();
        if (!msg.isEmpty()) {
            for (String key : emojiMap.keySet()) msg = msg.replace(key, emojiMap.get(key));
            try {
                dos.writeUTF("MSG");
                dos.writeUTF(username + ": " + msg);
                dos.flush();
                addMessage("You: " + msg, true);
            } catch (IOException ex) {
                addMessage("Failed to send message.", true);
            }
            textField.setText("");
            typingLabel.setText("Active now");
        }
    }

    void showTyping(String user) {
        typingLabel.setText(user + " is typing...");
        if (typingTimer != null && typingTimer.isRunning()) typingTimer.stop();
        typingTimer = new Timer(3000, e -> typingLabel.setText("Active now"));
        typingTimer.setRepeats(false);
        typingTimer.start();
    }

    void sendFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            try {
                FileInputStream fis = new FileInputStream(file);
                dos.writeUTF("FILE");
                dos.writeUTF(username);
                dos.writeUTF(file.getName());
                dos.writeLong(file.length());
                byte[] buffer = new byte[4096];
                int read;
                while ((read = fis.read(buffer)) > 0) dos.write(buffer, 0, read);
                dos.flush();
                fis.close();
                addMessage("You sent file: " + file.getName() +
                           " (" + (file.length() / 1024) + " KB)", true);
            } catch (IOException ex) {
                addMessage("File send failed.", true);
            }
        }
    }

    void addMessage(String message, boolean isMine) {
        JPanel msgBox = new JPanel(new BorderLayout());
        JTextArea msgArea = new JTextArea(
                message + "\n" + new SimpleDateFormat("hh:mm a").format(new Date()));
        msgArea.setWrapStyleWord(true); msgArea.setLineWrap(true);
        msgArea.setEditable(false); msgArea.setOpaque(true);
        msgArea.setBackground(isMine ? new Color(220, 248, 198) : Color.WHITE);
        msgArea.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        msgBox.add(msgArea, isMine ? BorderLayout.EAST : BorderLayout.WEST);
        chatPanel.add(msgBox);
        chatPanel.add(Box.createVerticalStrut(10));
        chatPanel.revalidate();
        SwingUtilities.invokeLater(() ->
            scrollPane.getVerticalScrollBar().setValue(scrollPane.getVerticalScrollBar().getMaximum())
        );
    }

    public Image makeRoundedImage(Image image) {
        int size = 50;
        BufferedImage rounded = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = rounded.createGraphics();
        g2.setClip(new java.awt.geom.Ellipse2D.Float(0, 0, size, size));
        g2.drawImage(image, 0, 0, size, size, null);
        g2.dispose();
        return rounded;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Client::new);
    }
}
