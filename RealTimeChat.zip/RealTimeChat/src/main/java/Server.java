/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author thorashim 
 */
// Server.java
import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
    static Vector<ClientHandler> clients = new Vector<>();

    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(50005);
        System.out.println("Server started on port 50005");

        while (true) {
            Socket socket = serverSocket.accept();
            ClientHandler handler = new ClientHandler(socket);
            clients.add(handler);
            handler.start();
        }
    }
}

class ClientHandler extends Thread {
    Socket socket;
    String username;
    DataInputStream dis;
    DataOutputStream dos;

    public ClientHandler(Socket socket) {
        try {
            this.socket = socket;
            dis = new DataInputStream(socket.getInputStream());
            dos = new DataOutputStream(socket.getOutputStream());

            username = dis.readUTF(); // receive username
            receiveProfilePicture();

            broadcast("MSG:" + username + " joined the chat.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void receiveProfilePicture() throws IOException {
        String filename = dis.readUTF();
        long size = dis.readLong();
        if (size > 0) {
            FileOutputStream fos = new FileOutputStream("profile_" + username + "_" + filename);
            byte[] buffer = new byte[4096];
            long remaining = size;
            while (remaining > 0) {
                int read = dis.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                if (read == -1) break;
                fos.write(buffer, 0, read);
                remaining -= read;
            }
            fos.close();
        }
    }

    public void run() {
        try {
            while (true) {
                String type = dis.readUTF();
                if (type.equals("MSG")) {
                    String msg = dis.readUTF();
                    broadcast("MSG:" + msg);
                } else if (type.equals("TYPING")) {
                    String typingUser = dis.readUTF();
                    for (ClientHandler c : Server.clients) {
                        if (c != this) {
                            c.dos.writeUTF("TYPING");
                            c.dos.writeUTF(typingUser);
                        }
                    }
                } else if (type.equals("FILE")) {
                    String sender = dis.readUTF();
                    String filename = dis.readUTF();
                    long size = dis.readLong();
                    for (ClientHandler c : Server.clients) {
                        if (c != this) {
                            c.dos.writeUTF("FILE");
                            c.dos.writeUTF(sender);
                            c.dos.writeUTF(filename);
                            c.dos.writeLong(size);
                        }
                    }
                    byte[] buffer = new byte[4096];
                    long remaining = size;
                    while (remaining > 0) {
                        int read = dis.read(buffer, 0, (int)Math.min(buffer.length, remaining));
                        if (read == -1) break;
                        for (ClientHandler c : Server.clients) {
                            if (c != this) {
                                c.dos.write(buffer, 0, read);
                                c.dos.flush();
                            }
                        }
                        remaining -= read;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println(username + " disconnected.");
            Server.clients.remove(this);
            broadcast("MSG:" + username + " left the chat.");
        }
    }

    void broadcast(String msg) {
        for (ClientHandler c : Server.clients) {
            try {
                c.dos.writeUTF("MSG");
                c.dos.writeUTF(msg);
                c.dos.flush();
            } catch (IOException ignored) {}
        }
    }
}
