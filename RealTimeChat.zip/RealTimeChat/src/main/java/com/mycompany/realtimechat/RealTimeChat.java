/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.realtimechat;

/**
 *
 * @author thorashim
 */
public class RealTimeChat {

    public static void main(String[] args) {
    }
}
